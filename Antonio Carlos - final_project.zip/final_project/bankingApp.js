// bankingApp.js: Core banking application logic
const fs = require('fs');
const readline = require('readline');
const User = require('./user');
const ETransfer = require('./etransfer');
const BankingSystem = require('./bankingSystem');

class BankingApp {
    constructor() {
        this.bankingSystem = new BankingSystem();  // Manages users and transactions
        this.currentUser = null;  // Current logged-in user
        this.rl = readline.createInterface({  // Readline interface for input/output
            input: process.stdin,
            output: process.stdout,
        });
    }

    // Prompt the user for input
    prompt(question) {
        return new Promise((resolve) => {
            this.rl.question(question, resolve);
        });
    }

    // Start the banking application
    async start() {
        console.log('Welcome to the Banking App!');
        if (!(await this.authenticate())) {
            this.rl.close();  // Exit if authentication fails
            return;
        }

        let running = true;
        while (running) {
            await this.displayMenu();
            const choice = await this.prompt('Enter your choice: ');
            running = await this.handleMenuChoice(choice);
        }
    }

    // Authenticate the user by email and PIN
    async authenticate() {
        const email = await this.prompt('Enter email: ');
        const user = this.bankingSystem.getUser(email);

        if (!user) {
            console.log('No user found with that email.');
            return false;
        }

        for (let attempts = 0; attempts < 3; attempts++) {
            const pin = await this.prompt('Enter PIN: ');
            const { success, message } = user.authenticate(pin);
            console.log(message);

            if (success) {
                this.currentUser = user;  // Set current user on success
                return true;
            }
        }

        console.log('Too many failed attempts. Try again later.');
        return false;
    }

    // Display the main menu
    async displayMenu() {
        console.log('\nMenu:');
        console.log('1. View Balance');
        console.log('2. Deposit Funds');
        console.log('3. Withdraw Funds');
        console.log('4. Change PIN');
        console.log('5. Send E-Transfer');
        console.log('6. Accept E-Transfer');
        console.log('7. Exit');
    }

    // Handle the user's menu choice
    async handleMenuChoice(choice) {
        switch (choice) {
            case '1':  // View Balance
                console.log(`Current balance: $${this.currentUser.balance}`);
                break;
            case '2':  // Deposit Funds
                const depositAmount = parseFloat(await this.prompt('Enter amount to deposit: '));
                if (depositAmount > 0) {
                    this.currentUser.balance += depositAmount;
                    console.log(`Deposited $${depositAmount}. New balance: $${this.currentUser.balance}`);
                } else {
                    console.log('Invalid amount.');
                }
                break;
            case '3':  // Withdraw Funds
                const withdrawAmount = parseFloat(await this.prompt('Enter amount to withdraw: '));
                if (withdrawAmount > 0 && withdrawAmount <= this.currentUser.balance) {
                    this.currentUser.balance -= withdrawAmount;
                    console.log(`Withdrew $${withdrawAmount}. New balance: $${this.currentUser.balance}`);
                } else {
                    console.log('Invalid or insufficient funds.');
                }
                break;
            case '4':  // Change PIN
                const newPin = await this.prompt('Enter new PIN: ');
                const confirmPin = await this.prompt('Re-enter new PIN: ');
                if (newPin === confirmPin) {
                    this.currentUser.changePin(newPin);
                    console.log('PIN successfully changed.');
                } else {
                    console.log('PINs do not match.');
                }
                break;
                
            case '5': // Send E-Transfer
                const recipientEmail = await this.prompt('Enter recipient email: ');
                const recipient = this.bankingSystem.getUser(recipientEmail);

                if (!recipient) {
                    console.log('Recipient not found.');
                    break;
                }

                const transferAmount = parseFloat(await this.prompt('Enter amount to send: '));
                if (transferAmount > 0 && transferAmount <= this.currentUser.balance) {
                    const securityQuestion = await this.prompt('Enter a security question: ');
                    const securityAnswer = await this.prompt('Enter the answer to the security question: ');

                    const transfer = {
                        amount: transferAmount,
                        question: securityQuestion,
                        answer: securityAnswer,
                    };

                    recipient.addETransfer(transfer);
                    this.currentUser.balance -= transferAmount;

                    console.log(`E-Transfer of $${transferAmount} sent to ${recipientEmail}.`);
                } else {
                    console.log('Invalid amount or insufficient funds.');
                }
                break;

            case '6': // Accept E-Transfer
                if (this.currentUser.pendingETransfers.length === 0) {
                    console.log('No pending e-transfers.');
                    break;
                }

                console.log('Pending E-Transfers:');
                this.currentUser.pendingETransfers.forEach((transfer, index) => {
                    console.log(`${index + 1}. Amount: $${transfer.amount}, Question: ${transfer.question}`);
                });

                const transferIndex = parseInt(await this.prompt('Enter the number of the transfer to accept: '), 10) - 1;

                if (transferIndex >= 0 && transferIndex < this.currentUser.pendingETransfers.length) {
                    const selectedTransfer = this.currentUser.pendingETransfers[transferIndex];
                    const answer = await this.prompt('Enter the answer to the security question: ');

                    if (answer === selectedTransfer.answer) {
                        this.currentUser.balance += selectedTransfer.amount;
                        this.currentUser.removeETransfer(transferIndex);
                        console.log(`E-Transfer of $${selectedTransfer.amount} accepted. New balance: $${this.currentUser.balance}`);
                    } else {
                        console.log('Incorrect answer.');
                    }
                } else {
                    console.log('Invalid selection.');
                }
                break;

            case '7':  // Exit the Application
                console.log('Exiting application. Thank you for using the Banking App!');
                this.bankingSystem.saveUsers();  // Save data before exiting
                this.rl.close();
                return false;
            default:
                console.log('Invalid choice.');
        }
        return true;
    }
}

module.exports = BankingApp;
