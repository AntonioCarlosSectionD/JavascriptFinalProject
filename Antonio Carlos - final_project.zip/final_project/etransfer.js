// etransfer.js: Contains the ETransfer class
class ETransfer {
    constructor(sender, recipient, amount, securityQuestion, securityAnswer) {
      this.sender = sender;  // Sender's email
      this.recipient = recipient;  // Recipient's email
      this.amount = amount;  // Transfer amount
      this.securityQuestion = securityQuestion;  // Security question for verification
      this.securityAnswer = securityAnswer;  // Security answer for validation
    }
  }
  
  module.exports = ETransfer;