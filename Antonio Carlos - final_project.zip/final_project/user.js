// user.js: Contains the User class
class User {
    constructor(email, pin, balance = 0) {
      this.email = email;  // User's email address
      this.pin = pin;      // User's security PIN
      this.balance = balance;  // User's account balance
      this.failedAttempts = 0; // Number of failed login attempts
      this.pendingETransfers = []; // List of pending e-transfers
    }
  
    // Authenticate the user's PIN
    authenticate(inputPin) {
      if (this.failedAttempts >= 10) {
        return { success: false, message: 'Account locked due to multiple failed attempts.' };
      }
  
      if (this.pin === inputPin) {
        this.failedAttempts = 0;  // Reset failed attempts on success
        return { success: true, message: 'Authentication successful.' };
      } else {
        this.failedAttempts += 1;  // Increment failed attempts
        return { success: false, message: 'Incorrect PIN.' };
      }
    }
  
    // Change the user's PIN
    changePin(newPin) {
      this.pin = newPin;
    }
  
    // Add a pending e-transfer to the user's list
    addETransfer(transfer) {
      this.pendingETransfers.push(transfer);
    }
  
    // Remove a completed e-transfer from the user's list
    removeETransfer(transferIndex) {
      this.pendingETransfers.splice(transferIndex, 1);
    }
  }
  
  module.exports = User;
  