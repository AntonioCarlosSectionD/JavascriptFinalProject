// utils.js: Utility functions
function validateAmount(amount) {
    return !isNaN(amount) && amount > 0;  // Check for valid amounts
  }
  
  module.exports = { validateAmount };
  