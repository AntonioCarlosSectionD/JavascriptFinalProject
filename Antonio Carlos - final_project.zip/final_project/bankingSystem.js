const fs = require('fs');
const path = require('path');
const User = require('./user');

class BankingSystem {
    constructor() {
        this.users = {};
        this.loadUsers();
    }

    loadUsers() {
        const filePath = path.join(__dirname, 'users.json');
        if (fs.existsSync(filePath)) {
            const data = fs.readFileSync(filePath);
            this.users = JSON.parse(data, (key, value) => {
                if (key === '') {
                    const users = {};
                    for (const [email, userData] of Object.entries(value)) {
                        users[email] = Object.assign(new User(), userData);
                    }
                    return users;
                }
                return value;
            });
        }
    }

    saveUsers() {
        const filePath = path.join(__dirname, 'users.json');
        fs.writeFileSync(filePath, JSON.stringify(this.users, null, 2));
    }

    addUser(email, pin, balance = 0) {
        if (!this.users[email]) {
            this.users[email] = new User(email, pin, balance);
        }
    }

    getUser(email) {
        return this.users[email];
    }
}

module.exports = BankingSystem;
