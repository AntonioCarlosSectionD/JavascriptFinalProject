// app.js: Entry point of the application
const BankingApp = require('./bankingApp');

// Start the application asynchronously
(async () => {
  const app = new BankingApp();
  await app.start();
})();